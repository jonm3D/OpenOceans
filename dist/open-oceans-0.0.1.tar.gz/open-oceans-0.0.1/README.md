# OpenOceans 

A repository for hosting tools related to ICESat-2 bathymetry.

You've found this while its still under development! Things may not work exactly as intended while bugs get ironed out.

__Jonathan Markel__<br />
Graduate Research Assistant<br /> 
3D Geospatial Laboratory<br />
The University of Texas at Austin<br />
jonathanmarkel@gmail.com<br />


